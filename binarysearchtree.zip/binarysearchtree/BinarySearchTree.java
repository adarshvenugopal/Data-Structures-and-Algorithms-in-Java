package binarysearchtree;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;
/**
 *
 * @author Adarsh
 */
public class BinarySearchTree {
    
    private Node root;
    
    public BinarySearchTree(){
        root = null;
    }
    
    public void insert(int data){
        root = insert(root,data);
    }
    
    private Node insert(Node node, int data){
        if(node == null){
            node = new Node(data);
        }
        else if(data <= node.getData()){
            node.setLeft(insert(node.getLeft(),data));
        }
        else{
            node.setRight(insert(node.getRight(),data));
        }
        return node;
    }
    
    public void delete(int data){
        root = delete(root, data);
    }
    
    public boolean isBST(){
        return isBSTHelper(root, Integer.MIN_VALUE, Integer.MAX_VALUE);
    }
    
    private boolean isBSTHelper(Node node, int lb, int ub){
        if(node == null) return true;
        if(node.getData() < lb || node.getData() > ub) return false;
        return isBSTHelper(node.getLeft(), lb, node.getData()) && isBSTHelper(node.getRight(), node.getData(), ub);
    }
    
    public static boolean isBSTsSame(BinarySearchTree bst1, BinarySearchTree bst2){
        return isBSTsSame(bst1.root, bst2.root);
    }
    private static boolean isBSTsSame(Node node1, Node node2){
        if(node1 == null && node2 == null) return true;
        if(node1 == null || node2 == null) return false;
        if(node1.getData() != node2.getData()) return false;
        return isBSTsSame(node1.getLeft(), node2.getLeft()) && isBSTsSame(node1.getRight(), node2.getRight());
    }    
    
    private Node delete(Node node, int data){
        if(node == null)return null;
        
        if(data < node.getData()){
            node.setLeft(delete(node.getLeft(),data));
        }
        else if(data > node.getData()){
            node.setRight(delete(node.getRight(),data));
        }
        else{
            if(node.getLeft() != null && node.getRight() != null){
                Node temp = findMin(node.getRight());
                node.setData(temp.getData());
                node.setRight(delete(node.getRight(),temp.getData()));
            }
            else if(node.getLeft() != null){
                node = node.getLeft();
            }
            else{
                node = node.getRight();
            }
        }
        return node;
    }    
    
    public boolean search(int data){
        return search(root, data);
    }
    
    private boolean search(Node node, int data){
        if(node == null){
            return false;
        }
        else if(data == node.getData()){
            return true;
        }
        else if(data < node.getData()){
            return search(node.getLeft(), data);
        }
        else{
            return search(node.getRight(), data);
        }
    }
    
    private Node findMin(Node node){
        if(node == null){
            System.out.println("Empty Tree!");
            return node;
        }
        else if(node.getLeft() == null){
            return node;
        }
        else{
            while(node.getLeft() != null){
                node = node.getLeft();
            }
            return node;
        }
    }
    
    public int findMin(){
        Node curr = root;
        
        if(curr == null){
            System.out.println("Empty Tree!");
            return -1;
        }
        else if(curr.getLeft() == null){
            return curr.getData();
        }
        else{
            while(curr.getLeft() != null){
                curr = curr.getLeft();
            }
            return curr.getData();
        }
    }
    
    public int findMax(){
        Node curr = root;
        
        if(curr == null){
            System.out.println("Empty Tree!");
            return -1;
        }
        else if(curr.getRight() == null){
            return curr.getData();
        }
        else{
            while(curr.getRight() != null){
                curr = curr.getRight();
            }
            return curr.getData();
        }
    }
    
    public int getHeight(){
        return getHeight(root);
    }
    
    private int getHeight(Node node){
        if(node == null)
            return -1;
        else
            return Math.max(getHeight(node.getLeft()),getHeight(node.getRight())) + 1;
    }
    
    public int getNoOfNodes(){
        return getNoOfNodes(root);
    }
    
    private int getNoOfNodes(Node node){
        if(node == null)
            return 0;
        else
            return getNoOfNodes(node.getLeft()) + getNoOfNodes(node.getRight()) + 1;
    }  
    
    public int getNoOfLeafNodes(){
        return getNoOfLeafNodes(root);
    }
    
    private int getNoOfLeafNodes(Node node){
        if(node == null)
            return 0;
        else if(node.getLeft() == null && node.getRight() == null)
            return 1;
        else
            return getNoOfLeafNodes(node.getLeft()) + getNoOfLeafNodes(node.getRight());
    }
    
    public void levelOrder(){
        levelOrder(root);
    }
    
    private void levelOrder(Node node){
        if(node == null)return;
        Queue<Node> q = new LinkedBlockingQueue<>();
        q.offer(node);
        
        while(!q.isEmpty()){
            Node temp = q.peek();
            System.out.printf("%d ", temp.getData());
            if(temp.getLeft() != null)
                q.offer(temp.getLeft());
            if(temp.getRight() != null)
                q.offer(temp.getRight());
            q.poll();
        }
    }
    
    public void preOrder(){
        preOrder(root);
    }
    
    public void inOrder(){
        inOrder(root);
    }

    public void postOrder(){
        postOrder(root);
    }    
    
    private void preOrder(Node node){
        if(node == null) return;
        System.out.printf("%d ", node.getData());
        preOrder(node.getLeft());
        preOrder(node.getRight());
    }
    
    private void inOrder(Node node){
        if(node == null) return;
        inOrder(node.getLeft());
        System.out.printf("%d ", node.getData());
        inOrder(node.getRight());
    }   
    
    private void postOrder(Node node){
        if(node == null) return;
        postOrder(node.getLeft());
        postOrder(node.getRight());
        System.out.printf("%d ", node.getData());
    }
    
    public int leastCommonAncestor(int a, int b){
        return leastCommonAncestor(root, a, b).getData();
    }
    
    private Node leastCommonAncestor(Node node, int a, int b){
        if(node == null) return node;
        if(node.getData() == a || node.getData() == b) return node;
        Node leftLCA = leastCommonAncestor(node.getLeft(), a, b);
        Node rightLCA = leastCommonAncestor(node.getRight(), a, b);
        
        if(leftLCA != null && rightLCA != null)
            return node;
        else if (leftLCA != null)
            return leftLCA;
        else
            return rightLCA;
    }
}
