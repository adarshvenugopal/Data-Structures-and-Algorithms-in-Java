package binarysearchtree;

/**
 *
 * @author Adarsh
 */
public class BinarySearchTreeDemo {
    public static void main(String...args){
        BinarySearchTree bst = new BinarySearchTree();
        
        bst.insert(10);
        bst.insert(5);
        bst.insert(50);
        bst.insert(33);
        bst.insert(25);
        bst.insert(8);
        bst.insert(2);
        bst.insert(19);
        
        BinarySearchTree bst2 = new BinarySearchTree();
        
        bst2.insert(10);
        bst2.insert(5);
        bst2.insert(50);
        bst2.insert(33);
        bst2.insert(25);
        bst2.insert(8);
        bst2.insert(2);
        bst2.insert(19);  

        BinarySearchTree bst3 = new BinarySearchTree();
        
        bst3.insert(10);
        bst3.insert(5);
        bst3.insert(50);
        bst3.insert(33);
        bst3.insert(25);
        bst3.insert(18);
        bst3.insert(2);
        bst3.insert(19);        

        System.out.printf("Is 2 is present in the tree? %s%n" , bst.search(2)? "Yes" : "No");
        System.out.printf("Is 19 is present in the tree? %s%n" , bst.search(19)? "Yes" : "No");
        System.out.printf("Is 29 is present in the tree? %s%n" , bst.search(29)? "Yes" : "No");
        
        System.out.printf("Minimum element in the tree is %d%n" , bst.findMin());
        System.out.printf("Maximum element in the tree is %d%n" , bst.findMax());
        
        System.out.printf("Height of the tree is %d%n" , bst.getHeight());
        System.out.printf("No of nodes in the tree is %d%n" , bst.getNoOfNodes());
        System.out.printf("No of leaf nodes in the tree is %d%n" , bst.getNoOfLeafNodes());
        
        System.out.println("Level order traversal of the tree:");
        bst.levelOrder();
        System.out.println();
        
        System.out.println("Pre order traversal of the tree:");
        bst.preOrder();
        System.out.println();  
        
        System.out.println("In order traversal of the tree:");
        bst.inOrder();
        System.out.println();   
        
        System.out.println("Post order traversal of the tree:");
        bst.postOrder();
        System.out.println(); 

        System.out.printf("Is bst same as bst2? %s%n" , BinarySearchTree.isBSTsSame(bst, bst2)? "Yes" : "No");      
        System.out.printf("Is bst same as bst3? %s%n" , BinarySearchTree.isBSTsSame(bst, bst3)? "Yes" : "No");      
        
        System.out.println("Deleting node with value 50 and 5 from the tree...");
        bst.delete(50);
        bst.delete(5);
        System.out.println(); 
        
        System.out.println("In order traversal post delete:");
        bst.inOrder();
        System.out.println();  
        
        System.out.printf("Is tree a binary search tree? %s%n" , bst.isBST()? "Yes" : "No");  
        
        System.out.printf("Lowest Common Ancestor of %d and %d is %d%n" , 2, 8, bst.leastCommonAncestor(2, 8));
        System.out.printf("Lowest Common Ancestor of %d and %d is %d%n" , 2, 19, bst.leastCommonAncestor(2, 19));
        System.out.printf("Lowest Common Ancestor of %d and %d is %d%n" , 33, 19, bst.leastCommonAncestor(33, 19));
    }
}
