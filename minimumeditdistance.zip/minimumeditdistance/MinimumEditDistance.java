/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package minimumeditdistance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 *
 * @author Adarsh
 */
public class MinimumEditDistance {
    
    static int[][] T;
    
    public static void main(String...args){
        String s1 = "saturday";
        String s2 = "sunday";
        
        int minDistance = minimumEditDistance(s1,s2);
        
        System.out.printf("Minimum distance to convert %s to %s is %d%n",s1,s2,minDistance);
        printConversions(T, s1, s2);
    }
    
    //Time Complexity is O(mn)
    //converting s1 to s2
    static int minimumEditDistance(String s1, String s2){
        int m = s2.length()+1;
        int n = s1.length()+1;
        T = new int[m][n];
        
        for(int i = 0; i < m ; i++){
            for(int j = 0; j < n ; j++){
                if(i == 0)//first row
                    T[i][j] = j;
                else if(j == 0)//first column
                    T[i][j] = i;
                else{//rest of the cells
                    
                    if(s2.charAt(i-1) == s1.charAt(j-1))
                        T[i][j] = T[i-1][j-1];
                    else
                        T[i][j] = Math.min(Math.min(T[i-1][j], T[i][j-1]), T[i-1][j-1])+1;
                }
            }
        }
        return T[m-1][n-1];
    }
    
    static void printConversions(int[][] T, String s1, String s2){
        List<Character> list = new ArrayList<>();
        int i = T.length - 1;
        int j = T[0].length - 1;
        int k = 0;
        while(true){
            if(i == 0 || j == 0)//i.e. either first row or first column, since we only populate it by default
                break;
            else if(s2.charAt(i-1) == s1.charAt(j-1)){//copy
                list.add('C');
                i = i - 1;
                j = j - 1;
            }
            else if(T[i][j] == T[i-1][j] + 1){//insert
                list.add('I');
                i = i - 1;
            }
            else if(T[i][j] == T[i][j-1] + 1){//delete
                list.add('D');
                j = j - 1;
            }
            else{//replace
                list.add('R');
                i = i - 1;
                j = j - 1;
            }
        }
        Collections.reverse(list);
        
        System.out.println("Order of operations are:");
        
        for(Character c : list){
            switch(c){
                case 'C':
                    System.out.printf("Copy %c%n", s1.charAt(k));
                    break;
                case 'I':
                    System.out.printf("Insert %c%n", s1.charAt(k));
                    break;
                case 'D':
                    System.out.printf("Delete %c%n", s1.charAt(k));
                    break;
                case 'R':
                    System.out.printf("Replace %c%n", s1.charAt(k));
                    break;
            }
            k++;
        }
        System.out.println();
    }
}
