package sortingalgorithms;

import java.util.Scanner;

/**
 *
 * @author Adarsh
 */
public class MergeSort {
    public static void main(String...args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter no of elements in the array:");
        int n = input.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter elements of the array:");
        
        for(int i=0;i<n;i++){
            arr[i] = input.nextInt();
        }
        
        System.out.println("Ths unsorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
        
        merge_sort(arr,n);
        System.out.println("Ths sorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
    }
    
    static void merge_sort(int[] arr, int n){
        if(n<2) return;
        int leftSize = n/2;
        int rightSize = n-leftSize;
        
        int[] leftArr = new int[leftSize];
        int[] rightArr = new int[rightSize];
        
        for(int i=0;i < leftSize; i++){
            leftArr[i] = arr[i];
        }
        for(int i=0;i < rightSize; i++){
            rightArr[i] = arr[i+leftSize];
        }
        merge_sort(leftArr, leftSize);
        merge_sort(rightArr, rightSize);
        merge(arr,leftArr,rightArr);
    }
    
    static void merge(int[] arr, int[] leftArr, int[] rightArr){
        int i,j,k;
        i = j = k = 0;
        
        while(i < leftArr.length && j < rightArr.length){
            if(leftArr[i] < rightArr[j]){
                arr[k] = leftArr[i];
                i++;
            }
            else {
                arr[k] = rightArr[j];
                j++;
            }
            k++;
        }
        while(i < leftArr.length){
            arr[k] = leftArr[i];
            k++;
            i++;
        }
        while(j < rightArr.length){
            arr[k] = rightArr[j];
            k++;
            j++;
        }        
    }
}
