package sortingalgorithms;

import java.util.Scanner;

/**
 * Time Complexity of this program is O(N^2) in the worst case and O(N) in the best case 
 * @author Adarsh
 */
public class InsertionSort {

    public static void main(String...args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter no of elements in the array:");
        int n = input.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter elements of the array:");
        
        for(int i=0;i<n;i++){
            arr[i] = input.nextInt();
        }
        
        System.out.println("Ths unsorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
        
        sort(arr,n);
        System.out.println("Ths sorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
    }
    
    static void sort(int[] arr, int n){
        if(n<1)return;
        
        for(int i = 1; i<n ;i++){
            int item = arr[i];
            int j = i-1;
            while(j>=0 && item < arr[j]){
                arr[j+1] = arr[j];
                j--;
            }
            arr[j+1] = item;
        }
    }    
    
}
