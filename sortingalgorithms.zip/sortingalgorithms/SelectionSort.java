package sortingalgorithms;

import java.util.Scanner;

/**
 * Time Complexity of this program is O(N^2) in both best and worst case
 * @author Adarsh
 */
public class SelectionSort {
    
    public static void main(String...args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter no of elements in the array:");
        int n = input.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter elements of the array:");
        
        for(int i=0;i<n;i++){
            arr[i] = input.nextInt();
        }
        
        System.out.println("Ths unsorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
        
        sort(arr,n);
        System.out.println("Ths sorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
    }
    
    static void sort(int[] arr, int n){
        if(n<1)return;
        int min;
        for(int i = 0; i <= n-2 ;i++){
            min = i;
            for(int j = i+1; j <= n-1; j++){
                if(arr[j]<arr[min])min = j;
            }
            int temp = arr[i];
            arr[i] = arr[min];
            arr[min] = temp;
        }
    }
    
}
