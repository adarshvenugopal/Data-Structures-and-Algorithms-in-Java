/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortingalgorithms;

import java.security.SecureRandom;
import java.util.Scanner;

/**
 *
 * @author Adarsh
 */
public class QuickSort {
    public static void main(String...args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter no of elements in the array:");
        int n = input.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter elements of the array:");
        
        for(int i=0;i<n;i++){
            arr[i] = input.nextInt();
        }
        
        System.out.println("Ths unsorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
        
        quick_sort(arr,0,n-1);
        System.out.println("The sorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
    } 
    
    static void quick_sort(int[] A, int start, int end){
        if(start >= end)return;
        
        int pivotPos = randomPartition(A,start,end);
        quick_sort(A, start, pivotPos-1);
        quick_sort(A, pivotPos+1, end);
    }
    
    static int randomPartition(int[] A, int start, int end){
        SecureRandom s = new SecureRandom();
        int randomPos = s.nextInt(end-start+1) + start;
        swap(A, randomPos, end);
        return partition(A, start, end);
    }
    
    static int partition(int[] A, int start, int end){
        
        int pivot = A[end];
        int pivotPos = start;
        
        for(int i = start; i < end; i++){
            if(A[i] <= pivot){
                swap(A, i, pivotPos);
                pivotPos++;
            }
        }
        swap(A, pivotPos, end);
        return pivotPos;
    }
    
    static void swap(int[] A , int index1, int index2){
        int temp = A[index1];
        A[index1] = A[index2];
        A[index2] = temp;
    }
}
