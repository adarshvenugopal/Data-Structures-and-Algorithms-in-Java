package sortingalgorithms;

import java.util.Scanner;

/**
 *
 * @author Adarsh
 */
public class BubbleSort {
    public static void main(String...args){
        Scanner input = new Scanner(System.in);
        System.out.println("Enter no of elements in the array:");
        int n = input.nextInt();
        
        int[] arr = new int[n];
        
        System.out.println("Enter elements of the array:");
        
        for(int i=0;i<n;i++){
            arr[i] = input.nextInt();
        }
        
        System.out.println("Ths unsorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
        
        sort(arr,n);
        System.out.println("Ths sorted array is:");
        for(int i : arr){
            System.out.printf("%d ",i);
        }
        System.out.println();
    }
    
    static void sort(int[] arr, int n){
        if(n<1)return;
        
        for(int i = 0; i<n ;i++){
            boolean flag = false;
            for(int j = 1; j< n-i;j++){
                
                if(arr[j] < arr[j-1]){
                    int temp = arr[j];
                    arr[j] = arr[j-1];
                    arr[j-1] = temp;
                    flag = true;
                }
            }
            
            if(!flag)break;
        }
    }     
}
